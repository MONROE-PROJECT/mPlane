# components

This repository contains various probe and repository components developed by the mPlane project against the mPlane SDK. The components here were removed from the [mPlane SDK](https://github.com/fp7mplane/protocol-ri) as part of the SDK release.

The `unported` directory contains components taken from older branches of the protocol reference implementation that have not yet been ported to the new `component.py` API. Once these components have been updated to the new API, they should be removed from this directory.
